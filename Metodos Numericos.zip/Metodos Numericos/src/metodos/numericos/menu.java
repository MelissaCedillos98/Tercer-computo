
package metodos.numericos;


/**
 *
 * @author hp
 */
public class menu {
    public void menu(){
int a;
int p;

leeint lee = new leeint();
newtonRaphson nr = new newtonRaphson();
InterNewton ni = new InterNewton();
fuera fue = new fuera();

do{
System.out.println("\n\n\t\t\tMETODOS NUMERICOS\n\n");
System.out.println("\t1.-Newton-Raphson\n\t2.-Interpolacion Newton\n\t3.-Salir");
System.out.println("\n\nEscoja el numero del metodo que desea usar:");
a=lee.leeint();
switch(a){
case 1:
nr.newtonRaphson();
p=fue.Fuera();
break;
case 2:
ni.InterNewton();
p=fue.Fuera();
break;
case 3:
System.exit(0);
break;
default:
System.out.println("Opcion incorrecta");
p=1;
break;
}
}while(a!=10);
}
}

