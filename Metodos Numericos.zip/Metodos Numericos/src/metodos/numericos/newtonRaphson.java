
package metodos.numericos;
/**
 *
 * @author hp
 */
public class newtonRaphson {
    
    public void newtonRaphson(){
        double a;
        double tol;
        double b;
        double c;
        lee rd= new lee();
        
    System.out.println("\t\t\t\"METODO DE NEWTON-RAPHSON\"");
    System.out.println("Primera Aproximacion: ");
    a=rd.lee();
    System.out.println("Tolerancia: ");
    tol=rd.lee();
    
    do{
        b=a-(a*a-a-2)/(2*a-1);
        c=Math.abs(a-b);
        a=b;
    }
    
    while(c==tol);
        System.out.println("La raiz es: "+b);
    }
}
