/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package metodos.numericos;

import java.io.*;

/**
 *
 * @author hp
 */
public class lee {
    public double lee(){
double num;
try{
InputStreamReader isr = new InputStreamReader (System.in);
BufferedReader br = new BufferedReader(isr);
String sdato;
sdato = br.readLine();
num = Double.parseDouble(sdato);
}
catch(IOException ioe){
num=0.0;
}
return num;
}
}
