/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package metodos.numericos;

import java.io.*;


public class leeint {
    public int leeint(){
int num;
try{
InputStreamReader isr = new InputStreamReader (System.in);
BufferedReader br = new BufferedReader(isr);
String sdato;
sdato = br.readLine();
num = Integer.parseInt(sdato);
}
catch(IOException ioe){
num=0;
}
return num;
}
}
