package metodos.numericos;
/**
 *
 * @author hp
 */
public class fuera {
    public int Fuera(){
int sal;
leeint out = new leeint();
System.out.println("\n\n\nSI DESEAS OTRO METODO PRESIONA [1]");
sal=out.leeint();
return sal;
}
}
